﻿// Fig. 14.32: ToolTipDemonstrationForm.cs
// Demonstrating the ToolTip component.
using System;
using System.Windows.Forms;

namespace ToolTipDemonstration
{
   public partial class ToolTipDemonstrationForm : Form
   {
      // default constructor
      public ToolTipDemonstrationForm()
      {
         InitializeComponent();
      } // end constructor

      // no event handlers needed for this example
   } // end class ToolTipDemonstrationForm
} // end namespace ToolTipDemonstration
