﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtensionMethodExample01
{
   public class MathOps
    {
        public double ADD(double num1, double num2)
        {
            return num1 + num2;
        } // end ADD

        public double SUB(double num1, double num2)
        {
            return num1 - num2;
        } // end SUB
    }
}
